function showMessage() {
    alert("Thanks for your message! I will get back to you soon.");
    return false; // Prevent form from actually submitting
  }
  